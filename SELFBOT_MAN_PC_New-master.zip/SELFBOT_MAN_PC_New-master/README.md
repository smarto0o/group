#SELFBOT_MAN_PC_NEW

[New] Bot Saling Backup Dan Admin Di Undang Jika Ke Kick

#Bot Protect Versi 5 Bot + 1 Backup

DoniSatria_OnePiece 5 Bot
DoniSatria BOT Protect Versi TCR
Bot Protect TCR Versi 5 Bot + Backup
Bot Line Versi Protect Group -Siapkan 6 Akun Bot Line Clone

Fungsinya Kelebihan : 
1.Protect Group Line 
2.Dapat Menambah Owner & Admin Bot
3.Command Bisa Dipakai oleh Admin 
4.Bot Tidak Saling Kick Ketika Ada Yang Terkick 
5.Jika Ingin Protect Lebih Dari 1 Group, Kalian Tidak Wajib ada di Semua Group Tersebut

Kelemahan: 1.BOT Tidak Aktif Ketika Bot Induk Tidak ada di Dalam Group

Cara Instal :

pkg install python -y
pkg install python2 -y
pkg install git -y
git clone https://github.com/selfbotman9999/SELFBOT_MAN_PC_New
pip2 install rsa
pip2 install thrift==0.9.3
pip2 install requests
Cara Menjalankan Botnya :

cd SELFBOT_MAN_PC_New
python2 5New.py

Add Me Line => 1ove..neverdie

Thanks For : Indonesia @ Thailand

Team SELFBOT_MAN_PROTECT
